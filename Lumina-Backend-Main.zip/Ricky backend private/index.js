const express = require("express");
const mongoose = require("mongoose");
const fs = require("fs");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const path = require("path");
const kv = require("./structs/kv.js");
const config = JSON.parse(fs.readFileSync("./Config/config.json").toString());
const WebSocket = require("ws");
const https = require("https");

const log = require("./structs/log.js");
const error = require("./structs/error.js");
const functions = require("./structs/functions.js");
const AutoBackendRestart = require("./structs/autobackendrestart.js");

const app = express();

// ===== BANNER ASCII SIMPLE =====
console.log(`
   
  _    _   _ __  __ ___ _   _    _     
| |  | | | |  \/  |_ _| \ | |  / \    
| |  | | | | |\/| || ||  \| | / _ \   
| |__| |_| | |  | || || |\  |/ ___ \  
|_____\___/|_|  |_|___|_| \_/_/   \_\ 
 
"HEY, HOSTER (ricky)"          Credits: Ricky012
`);
console.log('\x1b[92mStatus: backend running\x1b[0m\n'); // Status verde brillante
// ===============================

if (!fs.existsSync("./ClientSettings")) fs.mkdirSync("./ClientSettings");

global.JWT_SECRET = functions.MakeID();
const PORT = config.port;
const WEBSITEPORT = config.Website.websiteport;

let httpsServer;

if (config.bEnableHTTPS) {
    httpsServer = https.createServer({
        cert: fs.readFileSync(config.ssl.cert),
        ca: fs.existsSync(config.ssl.ca) ? fs.readFileSync(config.ssl.ca) : undefined,
        key: fs.readFileSync(config.ssl.key)
    }, app);
}

const tokens = JSON.parse(fs.readFileSync("./tokenManager/tokens.json").toString());

for (let tokenType in tokens) {
    for (let tokenIndex in tokens[tokenType]) {
        let decodedToken = jwt.decode(tokens[tokenType][tokenIndex].token.replace("eg1~", ""));
        if (DateAddHours(new Date(decodedToken.creation_date), decodedToken.hours_expire).getTime() <= Date.now()) {
            tokens[tokenType].splice(Number(tokenIndex), 1);
        }
    }
}

fs.writeFileSync("./tokenManager/tokens.json", JSON.stringify(tokens, null, 2));

global.accessTokens = tokens.accessTokens;
global.refreshTokens = tokens.refreshTokens;
global.clientTokens = tokens.clientTokens;
global.kv = kv;
global.exchangeCodes = [];

/* ===== UPDATE CHECKER RUN ===== */
/* El real no hace check de updates */
/* ============================================= */

mongoose.set("strictQuery", true);

mongoose.connect(config.mongodb.database, () => {
    log.backend("Database Connected");
});

mongoose.connection.on("error", err => {
    log.error("database failed to connect");
    throw err;
});

app.use(rateLimit({ windowMs: 0.5 * 60 * 1000, max: 55 }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

fs.readdirSync("./routes").forEach(fileName => {
    try {
        app.use(require(`./routes/${fileName}`));
    } catch {
        log.error(`Routes Error: Failed to load ${fileName}`);
    }
});

fs.readdirSync("./Api").forEach(fileName => {
    try {
        app.use(require(`./Api/${fileName}`));
    } catch {
        log.error(`backend API Error: Failed to load ${fileName}`);
    }
});

app.get("/unknown", (req, res) => {
    res.json({ msg: "Made by RickyonGit98" });
});

if (config.bEnableHTTPS) {
    httpsServer.listen(PORT, () => {
        log.backend(`Lumina is now listening on port ${PORT} with ssl`);
        require("./xmpp/xmpp.js");
        if (config.discord.bUseDiscordBot) require("./DiscordBot");
        if (config.bUseAutoRotate) require("./structs/autorotate.js");
    });
} else {
    app.listen(PORT, () => {
        log.backend(`Lumina listening port ${PORT}`);
        require("./xmpp/xmpp.js");
        if (config.discord.bUseDiscordBot) require("./DiscordBot");
        if (config.bUseAutoRotate) require("./structs/autorotate.js");
    });
}

if (config.bEnableAutoBackendRestart) {
    AutoBackendRestart.scheduleRestart(config.bRestartTime);
}

if (config.bEnableCalderaService) {
    const createCalderaService = require("./CalderaService/calderaservice");
    const calderaService = createCalderaService();

    if (!config.bGameVersion) {
        log.calderaservice("define a version in config");
        return;
    }

    if (config.bEnableHTTPS) {
        https.createServer({
            cert: fs.readFileSync(config.ssl.cert),
            ca: fs.existsSync(config.ssl.ca) ? fs.readFileSync(config.ssl.ca) : undefined,
            key: fs.readFileSync(config.ssl.key)
        }, calderaService).listen(config.bCalderaServicePort, () => {
            log.calderaservice(`Caldera Service started listening on port ${config.bCalderaServicePort} with ssl`);
        });
    } else {
        calderaService.listen(config.bCalderaServicePort, () => {
            log.calderaservice(`Caldera Service started listening on port ${config.bCalderaServicePort}`);
        });
    }
}

if (config.Website.bUseWebsite) {
    const websiteApp = express();
    require("./Website/website")(websiteApp);

    if (config.bEnableHTTPS) {
        https.createServer({
            cert: fs.readFileSync(config.ssl.cert),
            ca: fs.existsSync(config.ssl.ca) ? fs.readFileSync(config.ssl.ca) : undefined,
            key: fs.readFileSync(config.ssl.key)
        }, websiteApp).listen(WEBSITEPORT, () => {
            log.website(`Website started listening on port ${WEBSITEPORT} (SSL Enabled)`);
        });
    } else {
        websiteApp.listen(WEBSITEPORT, () => {
            log.website(`Website started listening on port ${WEBSITEPORT}`);
        });
    }
}

app.use((req, res) => {
    if (req.url.includes("..")) {
        res.redirect("https://github.com/RickyonGit98");
        return;
    }

    error.createError(
        "errors.com.epicgames.common.not_found",
        "Sorry the resource you were trying to find could not be found",
        undefined,
        1004,
        undefined,
        404,
        res
    );
});

function DateAddHours(date, hours) {
    date.setHours(date.getHours() + hours);
    return date;
}

module.exports = app;