const fs = require("fs");
const config = JSON.parse(fs.readFileSync("./Config/config.json").toString());

function getTimestamp() {
    const now = new Date();
    return `${now.toLocaleDateString('en-US')} ${now.toLocaleTimeString()}`;
}

function formatLog(prefixColor, prefix, ...args) {
    let msg = args.join(" ");
    console.log(`${prefixColor}[${getTimestamp()}] ${prefix}\x1b[0m: ${msg}\n`);
}

function backend(...args) {
    let msg = args.join(" ");

    // Database Connected → amarillo
    if (msg === "Database Connected") {
        if (config.bEnableFormattedLogs) {
            formatLog("\x1b[33m", "tity-backendLog", ...args);
        } else {
            console.log(`\x1b[33mInfo-Log\x1b[0m: ${msg}\n`);
        }
        return;
    }

    // Resto Info-Log → morado
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[35m", "tity-backendLog", ...args);
    } else {
        console.log(`\x1b[35mInfo-Log\x1b[0m: ${msg}\n`);
    }
}

function bot(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[33m", "Application Log", ...args);
    } else {
        console.log(`\x1b[33mnew bot Log\x1b[0m: ${msg}\n`);
    }
}

function xmpp(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[31m", "Xmpp Log", ...args);
    } else {
        console.log(`\x1b[31mLoginfo xmpp\x1b[0m: ${msg}\n`);
    }
}

function error(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[31m", "ocurred error Log", ...args);
    } else {
        console.log(`\x1b[31mUpdate Issue\x1b[0m: ${msg}\n`);
    }
}

function debug(...args) {
    if (config.bEnableDebugLogs) {
        let msg = args.join(" ");
        if (config.bEnableFormattedLogs) {
            formatLog("\x1b[35m", "backend log", ...args);
        } else {
            console.log(`\x1b[35mLuminaDebug Log\x1b[0m: ${msg}\n`);
        }
    }
}

function website(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[36m", "website Log", ...args);
    } else {
        console.log(`\x1b[36mWebsite Log\x1b[0m: ${msg}\n`);
    }
}

function AutoRotation(...args) {
    if (config.bEnableAutoRotateDebugLogs) {
        let msg = args.join(" ");
        if (config.bEnableFormattedLogs) {
            formatLog("\x1b[36m", "shop AutoRotation Debug Log", ...args);
        } else {
            console.log(`\x1b[36mshop AutoRotation Debug Log\x1b[0m: ${msg}\n`);
        }
    }
}

function checkforupdate(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[33m", "backend update Log", ...args);
    } else {
        console.log(`\x1b[33mbackend update Log\x1b[0m: ${msg}\n`);
    }
}

function autobackendrestart(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[92m", "Backend Restart Log", ...args);
    } else {
        console.log(`\x1b[92mBackend Restart\x1b[0m: ${msg}\n`);
    }
}

function calderaservice(...args) {
    let msg = args.join(" ");
    if (config.bEnableFormattedLogs) {
        formatLog("\x1b[91m", "Caldera Service Log", ...args);
    } else {
        console.log(`\x1b[91mCaldera Service\x1b[0m: ${msg}\n`);
    }
}

module.exports = {
    backend,
    bot,
    xmpp,
    error,
    debug,
    website,
    AutoRotation,
    checkforupdate,
    autobackendrestart,
    calderaservice
};
