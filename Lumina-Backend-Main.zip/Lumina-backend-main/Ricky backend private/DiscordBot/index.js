const { Client, Intents, MessageEmbed } = require("discord.js");
const fs = require("fs");
const path = require("path");

const client = new Client({
    intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MEMBERS,
        Intents.FLAGS.GUILD_BANS
    ]
});

const config = JSON.parse(fs.readFileSync("./Config/config.json", "utf8"));
const log = require("../structs/log.js");
const Users = require("../model/user.js");
const functions = require("../structs/functions.js");

/* ================= READY ================= */

client.once("ready", () => {
    log.bot("your application is now up");

    if (config.bEnableBackendStatus) {
        if (!config.bBackendStatusChannelId || config.bBackendStatusChannelId.trim() === "") {
            log.error("The channel ID has not been set in config.json for bEnableBackendStatus.");
        } else {
            const channel = client.channels.cache.get(config.bBackendStatusChannelId);
            if (!channel) {
                log.error(`Cannot find the channel with ID ${config.bBackendStatusChannelId}`);
            } else {
                const embed = new MessageEmbed()
                    .setTitle("backend uptime")
                    .setDescription("backend up")
                    .setColor("GREEN")
                    .setThumbnail("https://i.imgur.com/aXCZSzP.png")
                    .setFooter({
                        text: "Lumina",
                        iconURL: "https://i.imgur.com/aXCZSzP.png"
                    })
                    .setTimestamp();

                channel.send({ embeds: [embed] }).catch(err => log.error(err));
            }
        }
    }

    if (config.discord?.bEnableInGamePlayerCount) {
        const updateBotStatus = () => {
            if (Array.isArray(global.Clients)) {
                client.user.setActivity(
                    `${global.Clients.length} player(s)`,
                    { type: "WATCHING" }
                );
            }
        };

        updateBotStatus();
        setInterval(updateBotStatus, 10000);
    }

    const commands = client.application.commands;

    const loadCommands = (dir) => {
        for (const file of fs.readdirSync(dir)) {
            const filePath = path.join(dir, file);
            if (fs.lstatSync(filePath).isDirectory()) {
                loadCommands(filePath);
            } else if (file.endsWith(".js")) {
                const command = require(filePath);
                if (command.commandInfo) {
                    commands.create(command.commandInfo);
                }
            }
        }
    };

    loadCommands(path.join(__dirname, "commands"));
});

/* ================= SLASH COMMANDS ================= */

client.on("interactionCreate", async interaction => {
    if (!interaction.isApplicationCommand()) return;

    const executeCommand = (dir, name) => {
        const file = path.join(dir, `${name}.js`);
        if (fs.existsSync(file)) {
            require(file).execute(interaction);
            return true;
        }

        for (const sub of fs.readdirSync(dir)) {
            const subPath = path.join(dir, sub);
            if (fs.lstatSync(subPath).isDirectory()) {
                if (executeCommand(subPath, name)) return true;
            }
        }
        return false;
    };

    executeCommand(path.join(__dirname, "commands"), interaction.commandName);
});

/* ================= CROSS BANS ================= */

client.on("guildBanAdd", async ban => {
    if (!config.bEnableCrossBans) return;

    const memberBan = await ban.fetch();
    if (memberBan.user.bot) return;

    const userData = await Users.findOne({ discordId: memberBan.user.id });
    if (!userData || userData.banned === true) return;

    await userData.updateOne({ $set: { banned: true } });

    const refreshToken = global.refreshTokens?.findIndex(i => i.accountId === userData.accountId);
    if (refreshToken > -1) global.refreshTokens.splice(refreshToken, 1);

    const accessToken = global.accessTokens?.findIndex(i => i.accountId === userData.accountId);
    if (accessToken > -1) {
        global.accessTokens.splice(accessToken, 1);
        const xmppClient = global.Clients?.find(c => c.accountId === userData.accountId);
        if (xmppClient) xmppClient.client.close();
    }

    if (accessToken > -1 || refreshToken > -1) {
        await functions.UpdateTokens();
    }

    log.debug(`user ${memberBan.user.username} (ID: ${memberBan.user.id}) banned in discord and game`);
});

client.on("guildBanRemove", async ban => {
    if (!config.bEnableCrossBans) return;
    if (ban.user.bot) return;

    const userData = await Users.findOne({ discordId: ban.user.id });
    if (userData?.banned === true) {
        await userData.updateOne({ $set: { banned: false } });
        log.debug(`User ${ban.user.username} (ID: ${ban.user.id}) unbanned`);
    }
});

/* ================= ANTICRASH ================= */

client.on("error", err => console.log("Discord API Error:", err));
process.on("unhandledRejection", (reason, p) => console.log("Unhandled promise rejection:", reason, p));
process.on("uncaughtException", (err, origin) => console.log("Uncaught Exception:", err, origin));
process.on("uncaughtExceptionMonitor", (err, origin) => console.log("Uncaught Exception Monitor:", err, origin));

/* ================= LOGIN ================= */

if (!config.discord?.bot_token || typeof config.discord.bot_token !== "string") {
    console.error("❌ BOT TOKEN INVALID OR MISSING IN config.json");
    process.exit(1);
}

client.login(config.discord.bot_token);
